var searchData=
[
  ['init_5flevel_0',['init_level',['../game_8c.html#a11426211d309072d5acbef53783db681',1,'init_level(int level, char map[MAP_ROWS][MAP_COLS], GameState *state):&#160;game.c'],['../game_8h.html#a11426211d309072d5acbef53783db681',1,'init_level(int level, char map[MAP_ROWS][MAP_COLS], GameState *state):&#160;game.c']]],
  ['init_5fncurses_1',['init_ncurses',['../game_8c.html#a33290605d46d7f299b43e037d1c15348',1,'init_ncurses(void):&#160;game.c'],['../game_8h.html#a33290605d46d7f299b43e037d1c15348',1,'init_ncurses(void):&#160;game.c']]],
  ['is_5fadjacent_5fto_5fnpc_2',['is_adjacent_to_npc',['../game_8c.html#ad404cd562d442e7df738ff2f2ccc640d',1,'is_adjacent_to_npc(const GameState *state):&#160;game.c'],['../game_8h.html#ad404cd562d442e7df738ff2f2ccc640d',1,'is_adjacent_to_npc(const GameState *state):&#160;game.c']]]
];
