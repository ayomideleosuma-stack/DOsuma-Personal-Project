var searchData=
[
  ['level_0',['level',['../structGameState.html#ae455adb5fd873dd748ffae2db6255f87',1,'GameState']]],
  ['level_5fdone_1',['level_done',['../structGameState.html#acdb5ce4321c01223076a8712f6198047',1,'GameState']]]
];
