var searchData=
[
  ['update_5fnpc_0',['update_npc',['../game_8c.html#a3d72064160f449378b5fe1a62ad0b095',1,'update_npc(GameState *state, char map[MAP_ROWS][MAP_COLS]):&#160;game.c'],['../game_8h.html#a3d72064160f449378b5fe1a62ad0b095',1,'update_npc(GameState *state, char map[MAP_ROWS][MAP_COLS]):&#160;game.c']]]
];
