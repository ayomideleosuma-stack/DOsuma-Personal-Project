var searchData=
[
  ['map_5fcols_0',['MAP_COLS',['../game_8h.html#a0c8fa5f924e3cb0ab18aa9ef5563ec23',1,'game.h']]],
  ['map_5frows_1',['MAP_ROWS',['../game_8h.html#abeb9c94c1e5b0cb6b5aea0884b1fb942',1,'game.h']]]
];
