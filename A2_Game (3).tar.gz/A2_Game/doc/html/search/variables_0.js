var searchData=
[
  ['door_5fopen_0',['door_open',['../structGameState.html#a4a7114b07dc6550b9c72b99fa2f0024b',1,'GameState']]]
];
