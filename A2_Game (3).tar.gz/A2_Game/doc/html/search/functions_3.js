var searchData=
[
  ['handle_5fquit_5fprompt_0',['handle_quit_prompt',['../game_8c.html#af5ff1e12723fa9baf2d615a66896e991',1,'handle_quit_prompt(void):&#160;game.c'],['../game_8h.html#af5ff1e12723fa9baf2d615a66896e991',1,'handle_quit_prompt(void):&#160;game.c']]]
];
