var searchData=
[
  ['game_0',['A2 NCURSES GAME',['../index.html',1,'']]]
];
