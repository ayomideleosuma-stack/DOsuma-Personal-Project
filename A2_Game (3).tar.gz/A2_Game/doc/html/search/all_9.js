var searchData=
[
  ['paused_0',['paused',['../structGameState.html#a28ed035ace9259f3f8b07b2109a6f35d',1,'GameState']]],
  ['play_5flevel_1',['play_level',['../game_8c.html#a6a755e614b2f9a46691744323e6a9570',1,'play_level(int level):&#160;game.c'],['../game_8h.html#a6a755e614b2f9a46691744323e6a9570',1,'play_level(int level):&#160;game.c']]],
  ['player_5fx_2',['player_x',['../structGameState.html#a102f7c6f6108aad447064fdf6b018073',1,'GameState']]],
  ['player_5fy_3',['player_y',['../structGameState.html#a1cbe53144f0f02540aa49a213274873d',1,'GameState']]]
];
