var searchData=
[
  ['draw_5fgame_0',['draw_game',['../game_8c.html#a4ee50154e786e239fe5dc5b1ddd84304',1,'draw_game(const char map[MAP_ROWS][MAP_COLS], const GameState *state):&#160;game.c'],['../game_8h.html#a4ee50154e786e239fe5dc5b1ddd84304',1,'draw_game(const char map[MAP_ROWS][MAP_COLS], const GameState *state):&#160;game.c']]]
];
