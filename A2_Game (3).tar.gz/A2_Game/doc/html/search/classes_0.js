var searchData=
[
  ['gamestate_0',['GameState',['../structGameState.html',1,'']]]
];
