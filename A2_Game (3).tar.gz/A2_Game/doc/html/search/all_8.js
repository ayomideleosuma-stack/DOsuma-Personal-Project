var searchData=
[
  ['ncurses_20game_0',['A2 NCURSES GAME',['../index.html',1,'']]],
  ['npc_5fdir_1',['npc_dir',['../structGameState.html#adaa66941575585ebd2c9711073b5a04a',1,'GameState']]],
  ['npc_5fx_2',['npc_x',['../structGameState.html#a3eefa4a6eeef48df03703d812aa9b136',1,'GameState']]],
  ['npc_5fy_3',['npc_y',['../structGameState.html#acbfa4bd5b360d5c26812608424f31a51',1,'GameState']]]
];
