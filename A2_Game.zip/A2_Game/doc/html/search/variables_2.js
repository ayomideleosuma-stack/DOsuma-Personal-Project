var searchData=
[
  ['info_0',['info',['../structGameState.html#a68508ba10ad6d4d574b87ed2148b5c59',1,'GameState']]]
];
