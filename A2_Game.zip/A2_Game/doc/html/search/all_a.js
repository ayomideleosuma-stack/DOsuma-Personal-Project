var searchData=
[
  ['running_0',['running',['../structGameState.html#a30601d3ba033f5485b57107547ce6b44',1,'GameState']]]
];
