var searchData=
[
  ['a2_20ncurses_20game_0',['A2 NCURSES GAME',['../index.html',1,'']]]
];
