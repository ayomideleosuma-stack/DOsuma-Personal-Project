var searchData=
[
  ['play_5flevel_0',['play_level',['../game_8c.html#a6a755e614b2f9a46691744323e6a9570',1,'play_level(int level):&#160;game.c'],['../game_8h.html#a6a755e614b2f9a46691744323e6a9570',1,'play_level(int level):&#160;game.c']]]
];
