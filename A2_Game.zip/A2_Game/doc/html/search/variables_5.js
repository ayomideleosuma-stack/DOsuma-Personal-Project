var searchData=
[
  ['paused_0',['paused',['../structGameState.html#a28ed035ace9259f3f8b07b2109a6f35d',1,'GameState']]],
  ['player_5fx_1',['player_x',['../structGameState.html#a102f7c6f6108aad447064fdf6b018073',1,'GameState']]],
  ['player_5fy_2',['player_y',['../structGameState.html#a1cbe53144f0f02540aa49a213274873d',1,'GameState']]]
];
