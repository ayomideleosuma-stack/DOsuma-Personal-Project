var searchData=
[
  ['shutdown_5fncurses_0',['shutdown_ncurses',['../game_8c.html#ae496a0a3f257003728ed0da2ba6ea734',1,'shutdown_ncurses(void):&#160;game.c'],['../game_8h.html#ae496a0a3f257003728ed0da2ba6ea734',1,'shutdown_ncurses(void):&#160;game.c']]],
  ['splash_5fscreen_1',['splash_screen',['../menu_8c.html#a67fa01af150840ef4ffded18d809f684',1,'splash_screen(void):&#160;menu.c'],['../menu_8h.html#a67fa01af150840ef4ffded18d809f684',1,'splash_screen(void):&#160;menu.c']]]
];
